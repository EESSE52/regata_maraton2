# generador_web.py
# CORREGIDO: Añadida una página interactiva para el Programa de Regatas con enlaces a los resultados.

import os
import sqlite3
from PySide6.QtGui import QTextDocument
import database_maraton as db
from generador_pdf_reportes import (
    crear_resultados_categoria, 
    crear_puntuacion_general, 
    image_to_base64
)

# --- (CSS_STYLES y crear_pagina_html no cambian) ---
CSS_STYLES = """
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    line-height: 1.6;
    background-color: #f4f7f6;
    color: #333;
    margin: 0;
    padding: 20px;
}
.container {
    max-width: 960px;
    margin: 0 auto;
    background: #fff;
    padding: 20px 30px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
.header {
    border-bottom: 2px solid #0056b3;
    padding-bottom: 15px;
    margin-bottom: 20px;
    text-align: center;
}
.header h1 {
    margin: 0;
    color: #0056b3;
    font-size: 2.5em;
}
.header h2 {
    margin: 5px 0 0;
    font-weight: normal;
    color: #666;
}
.report-title, .index-title {
    text-align: center;
    font-size: 1.8em;
    margin-bottom: 25px;
    color: #333;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}
th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
    vertical-align: middle;
}
th {
    background-color: #e9ecef;
    font-weight: bold;
}
tbody tr:nth-child(odd) {
    background-color: #f8f9fa;
}
.center { text-align: center; }
.rank { font-weight: bold; text-align: center; }
.boat-details p { margin: 0; padding: 0; line-height: 1.3; }
.boat-details .club { font-weight: bold; }
.club-logo { max-height: 16px; vertical-align: middle; margin-right: 6px; }
ul.report-list {
    list-style: none;
    padding: 0;
}
ul.report-list li {
    background: #e9ecef;
    margin-bottom: 10px;
    border-radius: 5px;
}
ul.report-list li a {
    display: block;
    padding: 15px;
    text-decoration: none;
    color: #0056b3;
    font-weight: bold;
    transition: background-color 0.2s ease-in-out;
}
ul.report-list li a:hover {
    background-color: #d8e2ef;
}
.footer {
    text-align: center;
    margin-top: 30px;
    padding-top: 15px;
    border-top: 1px solid #ddd;
    font-size: 0.9em;
    color: #777;
}
"""

def crear_pagina_html(titulo, contenido_body, es_index=False):
    """Envuelve el contenido HTML en una estructura de página completa."""
    # ajusta la ruta del css si no es una página de resultados
    ruta_css = "style.css" if es_index else "../style.css"
    
    if "<body>" in contenido_body:
        start = contenido_body.find("<body>") + len("<body>")
        end = contenido_body.rfind("</body>")
        contenido_body = contenido_body[start:end]

    return f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{titulo}</title>
        <link rel="stylesheet" href="{ruta_css}">
    </head>
    <body>
        <div class="container">
            {contenido_body}
        </div>
    </body>
    </html>
    """

# --- NUEVA FUNCIÓN ---
def generar_pagina_programa(evento_id):
    """Genera el contenido HTML para la página del programa de regatas."""
    programa = db.obtener_programa_pruebas(evento_id)
    
    html_body = f"<div class='report-title'>Programa de Regatas</div>"
    html_body += "<table><thead><tr><th class='center'>Hora</th><th>Prueba / Categoría</th></tr></thead><tbody>"
    
    for _, nombre_cat, codigo_cat, hora in programa:
        # Creamos el nombre del archivo de resultados para enlazarlo
        nombre_archivo_resultados = f"resultados_{codigo_cat.lower().replace(' ', '_')}.html"
        enlace_resultados = f"resultados/{nombre_archivo_resultados}"
        
        html_body += f"""
        <tr>
            <td class='center'><b>{hora or 'A definir'}</b></td>
            <td><a href='{enlace_resultados}'>{nombre_cat} ({codigo_cat})</a></td>
        </tr>
        """
    html_body += "</tbody></table>"
    
    doc = QTextDocument()
    doc.setHtml(html_body)
    return doc.toHtml()


def generar_sitio_completo(evento_id, sistema_puntuacion, output_dir):
    """Función principal que genera todo el sitio web."""
    ruta_resultados = os.path.join(output_dir, "resultados")
    os.makedirs(ruta_resultados, exist_ok=True)

    evento_info = db.obtener_info_evento(evento_id)
    if not evento_info:
        raise ValueError("No se pudo encontrar el evento.")
    nombre_evento, fecha_evento = evento_info[1], evento_info[2]
    
    with open(os.path.join(output_dir, "style.css"), "w", encoding="utf-8") as f:
        f.write(CSS_STYLES)

    enlaces_reportes = []
    
    # --- AÑADIMOS EL NUEVO REPORTE DEL PROGRAMA ---
    enlaces_reportes.append({'titulo': 'Programa de Regatas', 'url': 'programa.html'})
    contenido_programa_html = generar_pagina_programa(evento_id)
    pagina_completa_programa = crear_pagina_html(f"Programa - {nombre_evento}", contenido_programa_html, es_index=True)
    with open(os.path.join(output_dir, "programa.html"), "w", encoding="utf-8") as f:
        f.write(pagina_completa_programa)
    
    # --- Generamos el resto de las páginas como antes ---
    categorias = db.obtener_categorias()
    for cat_id, nombre_categoria, codigo_cat, *_ in categorias:
        doc, _ = crear_resultados_categoria(evento_id, cat_id, None, [])
        if doc and not doc.isEmpty():
            nombre_archivo_limpio = f"resultados_{codigo_cat.lower().replace(' ', '_')}.html"
            enlaces_reportes.append({'titulo': f"Resultados - {nombre_categoria}", 'url': f"resultados/{nombre_archivo_limpio}"})
            contenido_html = crear_pagina_html(f"Resultados - {nombre_categoria}", doc.toHtml())
            with open(os.path.join(ruta_resultados, nombre_archivo_limpio), "w", encoding="utf-8") as f:
                f.write(contenido_html)

    reportes_generales = [
        ("Clasificación General por Clubes", "clasificacion_general_clubes.html", crear_puntuacion_general, (evento_id, sistema_puntuacion, None, [])),
        ("Ranking Individual por Puntos", "ranking_individual_puntos.html", db.calcular_puntuacion_deportistas, (evento_id, sistema_puntuacion)),
        ("Ranking Individual por Medallas", "ranking_individual_medallas.html", db.calcular_ranking_medallas_deportistas, (evento_id,))
    ]
    
    for titulo, nombre_archivo, func, args in reportes_generales:
        doc_html = ""
        if "Clasificación General" in titulo:
             doc, _ = func(*args)
             if doc: doc_html = doc.toHtml()
        else:
             html_body = ""
             if "Puntos" in titulo:
                 ranking = func(*args)
                 html_body = f"<div class='report-title'>{titulo}</div><table><thead><tr><th class='center'>Lugar</th><th>Deportista</th><th>Club</th><th class='center'>Puntos</th></tr></thead><tbody>"
                 for i, data in enumerate(ranking):
                     logo_b64 = image_to_base64(data.get('logo_path'))
                     logo_html = f'<img src="{logo_b64}" class="club-logo">' if logo_b64 else ''
                     html_body += f"""<tr><td class="center">{i+1}</td><td>{data['nombre']}</td><td>{logo_html}{data['club']}</td><td class="center">{data['puntos']}</td></tr>"""
                 html_body += "</tbody></table>"
             elif "Medallas" in titulo:
                 medallero = func(*args)
                 html_body = f"<div class='report-title'>{titulo}</div><table><thead><tr><th class='center'>Lugar</th><th>Deportista</th><th>Club</th><th class='center'>🥇</th><th class='center'>🥈</th><th class='center'>🥉</th></tr></thead><tbody>"
                 for i, data in enumerate(medallero):
                     logo_b64 = image_to_base64(data.get('logo_path'))
                     logo_html = f'<img src="{logo_b64}" class="club-logo">' if logo_b64 else ''
                     html_body += f"""<tr><td class="center">{i+1}</td><td>{data['nombre']}</td><td>{logo_html}{data['club']}</td><td class="center">{data['oro']}</td><td class="center">{data['plata']}</td><td class="center">{data['bronce']}</td></tr>"""
                 html_body += "</tbody></table>"
             
             if html_body:
                doc = QTextDocument(); doc.setHtml(html_body)
                doc_html = doc.toHtml()
        
        if doc_html:
            enlaces_reportes.append({'titulo': titulo, 'url': f"resultados/{nombre_archivo}"})
            contenido_html = crear_pagina_html(titulo, doc_html)
            with open(os.path.join(ruta_resultados, nombre_archivo), "w", encoding="utf-8") as f:
                f.write(contenido_html)

    index_html = f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Resultados: {nombre_evento}</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>{nombre_evento}</h1>
                <h2>{fecha_evento}</h2>
            </div>
            <h2 class="index-title">Índice de Resultados</h2>
            <ul class="report-list">
    """
    for enlace in enlaces_reportes:
        index_html += f"<li><a href='{enlace['url']}'>{enlace['titulo']}</a></li>"
    
    index_html += """
            </ul>
            <div class="footer">
                <p>Sitio generado por Gestor de Regatas.</p>
            </div>
        </div>
    </body>
    </html>
    """
    with open(os.path.join(output_dir, "index.html"), "w", encoding="utf-8") as f:
        f.write(index_html)

    return True